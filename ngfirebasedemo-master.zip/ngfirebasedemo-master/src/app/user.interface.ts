export interface User{
    email:string;
    password:string;
    confirmpassword:string;
}